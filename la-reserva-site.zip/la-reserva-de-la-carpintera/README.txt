LA RESERVA DE LA CARPINTERA — site files

index.html    the page
styles.css    all styling (colours and fonts are at the top, under "TOKENS")
images/       63 photographs; each appears once on the page.
              Sizes: name-400.webp (small), name-720.webp and name-1440.webp (large).
fonts/        two typefaces, both open licence (licence files alongside):
              Yeseva One for headlines, Bricolage Grotesque (sans serif) for everything else.
              To change either, edit --display or --font at the top of styles.css.

There is no JavaScript. Upload the whole folder as it is.

ON PHONES
- The ring and the "one day" viewer are turned by swiping; the five reasons are swipe cards.
- As you scroll, sections rise into place and the hero photographs fly outward.
- Browsers that cannot tie motion to scrolling (older iPhones, some Android browsers)
  show the same page with tap controls instead. Nothing is hidden from them.

BEFORE PUBLISHING
1. Replace hello@example.com in index.html with your email address.
2. ORGANIC: the page calls the coffee organic. If the farm is certified, add the certifier's
   name where the comment marked ORGANIC says. If it is not certified, change the wording first.
3. In the section marked THE COFFEE, replace the general Tres Rios tasting notes with
   the notes from your own coffee, and correct the six facts if any differ for your farm.

TO ADD OR SWAP PHOTOGRAPHS (each place has a comment in index.html)
- Hero ring of small photos: change a file name inside <div class="scatter"> (use the -400 size).
- Walk the reserve (3D ring): see the comment above <div class="wheel">.
- One day in the reserve (lens viewer): see the comment inside <section class="lens">.
- Field notes: copy one <img> line inside <div class="notes-grid">.
- Export each photo as WebP at 400, 720 and 1440 px on the long edge.
- Each photograph is used in one place only. When you add one, put it in a single section.
